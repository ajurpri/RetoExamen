   // Variables globales
        let todosLosPaises = [];
        const cuerpoTabla = document.getElementById('cuerpoTabla');
        const inputBusqueda = document.getElementById('inputBusqueda');

        // 1. Pedir los datos a la API
        fetch('https://restcountries.com/v3.1/all?fields=name,capital,region,population')
            .then(res => res.json()) // Convertir respuesta a JSON
            .then(data => {
                todosLosPaises = data; // Guardamos los datos
                mostrarDatos(todosLosPaises); // Mostramos todo al principio
            });

        // 2. Función para pintar la tabla
        function mostrarDatos(listaPaises) {
            cuerpoTabla.innerHTML = ''; // Borramos lo que haya antes

            listaPaises.forEach(pais => {
                // Algunos países no tienen capital, así que ponemos un guión si falla
                let capital = "No tiene";
                if (pais.capital) {
                    capital = pais.capital[0];
                }

                // Creamos la fila (TR)
                const fila = `
                    <tr>
                        <td>${pais.name.common}</td>
                        <td>${capital}</td>
                        <td>${pais.region}</td>
                        <td>${pais.population}</td>
                    </tr>
                `;

                // Añadimos la fila a la tabla (manera sencilla, aunque no la más rápida)
                cuerpoTabla.innerHTML += fila;
            });
        }

        // 3. Evento para filtrar cuando escribes
        inputBusqueda.addEventListener('keyup', (e) => {
            const texto = e.target.value.toLowerCase();

            // Filtramos la lista original
            const paisesFiltrados = todosLosPaises.filter(pais => {
                const nombrePais = pais.name.common.toLowerCase();
                return nombrePais.includes(texto);
            });

            // Volvemos a pintar la tabla con los filtrados
            mostrarDatos(paisesFiltrados);
        });
